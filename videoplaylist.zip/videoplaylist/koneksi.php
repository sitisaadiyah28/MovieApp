<?php 
	$connect = new mysqli('localhost','root','','dbvideo');
	
	if($connect){

	}else{
		echo "Database gagal";
	}
	

?>