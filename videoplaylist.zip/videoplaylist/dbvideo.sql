-- phpMyAdmin SQL Dump
-- version 4.7.4
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: 29 Jun 2020 pada 17.44
-- Versi Server: 10.1.29-MariaDB
-- PHP Version: 7.2.0

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET AUTOCOMMIT = 0;
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `dbvideo`
--

-- --------------------------------------------------------

--
-- Struktur dari tabel `tb_genre`
--

CREATE TABLE `tb_genre` (
  `id_genre` int(11) NOT NULL,
  `nama_genre` varchar(225) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data untuk tabel `tb_genre`
--

INSERT INTO `tb_genre` (`id_genre`, `nama_genre`) VALUES
(1, 'islamic'),
(2, 'horor'),
(3, 'action');

-- --------------------------------------------------------

--
-- Struktur dari tabel `tb_movie`
--

CREATE TABLE `tb_movie` (
  `id_video` int(11) NOT NULL,
  `title` varchar(225) NOT NULL,
  `deskripsi` text NOT NULL,
  `id_genre` int(11) NOT NULL,
  `image` varchar(225) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data untuk tabel `tb_movie`
--

INSERT INTO `tb_movie` (`id_video`, `title`, `deskripsi`, `id_genre`, `image`) VALUES
(2, 'Ajari Aku Islam', 'Ajari Aku Islam merupakan karya sutradara Deni Pusung dan penulis naskah Haris Suhud dan Yunita R Saragi. Film yang diangkat dari kisah nyata ini berada dalam naungan studio produksi RA pictures dan Retro Pictures. Deni Pusung merupakan sutradara Senjakala di Manado (2016) dan Hantu Nancy (2015).\r\n\r\nBaca selengkapnya di artikel \"Sinopsis Ajari Aku Islam, Film Roger & Cut Meyriska Rilis Hari Ini\"', 1, 'ajari.jpg'),
(3, 'Nenek Gayung', 'NENEK GAYUNG adalah sebuah film horor komedi yang diangkat dari fenomena menyeramkan. Kisah tersebut sempat jadi bahan perbincangan warga pinggiran Jakarta pada akhir tahun 2011. Sayangnya, film yang disutradarai oleh Nuri Dahlia ini terlihat kurang fokus dalam penggarapannya.', 2, 'nenek.jpg'),
(6, 'Surga Yang Tak Dirindukan', 'Surga yang Tak Dirindukan adalah film drama Indonesia yang dirilis pada tahun 2015. Diangkat dari novel karya Asma Nadia dengan judul sama, film ini dibintangi oleh Fedi Nuril sebagai Prasetya, seorang arsitek yang terpaksa menikahi seorang wanita depresi demi menyelamatkan nyawanya, Laudya Cynthia Bella sebagai Arini, istri dan cinta sejati Prasetya, dan Raline Shah sebagai Mei Rose, seorang wanita depresi yang diselamatkan oleh Prasetya dan menimbulkan berbagai konflik dalam rumah tangga Prasetya dan Arini.', 1, 'surga.jpg'),
(7, 'Ketika Cinta Bertasbih', 'Ketika Cinta Bertasbih merupakan film Indonesia yang dirilis pada tanggal 19 Juni 2009 yang disutradarai oleh Chaerul Umam. Film ini dibintangi antara lain oleh Kholidi Asadil Alam, Oki Setiana Dewi, Alice Norin, Andi Arsyil Rahman, Meyda Sefira, Deddy Mizwar, Niniek L. Karim, Didi Petet, Habiburrahman El Shirazy, Aspar Paturusi, Din Syamsudin, Slamet Rahardjo, dan El Manik.', 1, 'ketika.jpg'),
(8, 'Assalammu\'alaikum Beijing', 'Dewa dan Ra adalah busur dan anak panah. Keduanya memiliki bidikan yang sama, sebuah titik bernama istana cinta. Tapi arah angin mengubah Dewa. Sebagai busur, dia memilih sasarannya sendiri dan membiarkan anak panah melesat tanpa daya. Sebagai laki-laki pengagum mitologi, Zhongwen ibarat kesatria tanpa kuda. Sikapnya santun dan perangainya gagah, tetapi langkahnya tak tentu arah. Dia berburu sampai negeri jauh untuk mencari Tuhan sekaligus menemukan Asma, anak panah yang sanggup meruntuhkan tembok besar yang membentengi hatinya. Asma yang berjuang melupakan lelaki berahang kukuh yang diam-diam memujanya. Kisah cinta yang datang menyapa bertujuan menentukan takdir mereka menjalani kehidupan di dunia.', 1, 'beijing.jpg'),
(9, 'Aisyah', 'Aisyah: Biarkan Kami Bersaudara merupakan film ketiga garapan rumah produksi Film One Production yang diangkat dari kisah nyata tentang balada seorang perempuan muslim, ketika menjadi guru sebuah sekolah dasar di desa terpencil Atambua, Nusa Tenggara Timur.\r\n\r\nDiceritakan, gadis bernama Aisyah yang baru saja lulus dari sarjana ini. Demi mengejar cita-citanya sejak sebelum kuliah berkeinginan untuk mengabdikan dirinya sebagai seorang guru, harus meninggalkan kampung halamannya nan sejuk dan sarat dengan nilai religius di Ciwidey, Jawa Barat.', 1, 'aisyah.jpg'),
(10, 'Tabu', 'Tabu: Mengusik Gerbang Iblis. ... Di sana, mereka melanggar aturan-aturan yang ada dan melakukan berbagai hal yang sangat dianggap tabu. Setelah pulang, hidup mereka pun mendadak berubah. Hilangnya Diaz dan hadirnya bocah misterius yang dibawa Keyla pulang menjadi awal dari teror kehidupan mereka.', 2, 'tabu.jpg'),
(11, 'Sinister', 'Film Sinister merupakan sebuah film yang disutradarai oleh Scott Derrickson. Film ini diperankan diantaranya oleh Ethan Hawke, Juliet Rylance, James Ransone. \r\n\r\nFilm ini bercerita tentang Ellison, seorang penulis novel kriminal terkenal yang dalam proses penulisan buku terbarunya ia kesulitan untuk menjadi ide. \r\n\r\nDemi mendapatkan inspirasi dan mendalami tulisannya ia dan keluarganya pindah ke sebuah rumah. Rumah itu bukanlah rumah biasa. Ellison menemukan sekotak video yang berisi rekaman pembunuhan beberapa keluarga yag dilakukan secara brutal', 2, 'sinister.jpg'),
(12, 'Danur', 'Film berdurasi 78 menit tersebut mengisahkan tentang indigo Risa Saraswati yang bersahabat dengan teman-teman hantunya. Risa kecil sering merasa kesepian karena kesibukan masing-masing ayah dan ibunya. Hingga pada ulang tahun ke-8, Risa berdoa agar tidak sendiri lagi dan mendapatkan teman baru.', 2, 'danur.jpg');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `tb_genre`
--
ALTER TABLE `tb_genre`
  ADD PRIMARY KEY (`id_genre`);

--
-- Indexes for table `tb_movie`
--
ALTER TABLE `tb_movie`
  ADD PRIMARY KEY (`id_video`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `tb_genre`
--
ALTER TABLE `tb_genre`
  MODIFY `id_genre` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=4;

--
-- AUTO_INCREMENT for table `tb_movie`
--
ALTER TABLE `tb_movie`
  MODIFY `id_video` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=13;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
