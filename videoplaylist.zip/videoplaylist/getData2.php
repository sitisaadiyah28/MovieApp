<?php

include 'koneksi.php';

$data = $connect->query("SELECT * FROM tb_movie INNER JOIN tb_genre ON tb_movie.id_genre = tb_genre.id_genre where tb_movie.id_genre=2");

$result = array();
while($tampil = $data->fetch_assoc()) {
	$result[] = $tampil;
}

echo json_encode($result);
?>