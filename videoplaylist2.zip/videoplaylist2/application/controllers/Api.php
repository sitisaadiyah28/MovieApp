<?php
	
	defined('BASEPATH') OR exit ('No Script Direct');

	class Api extends CI_Controller{

		function __construct(){
			parent::__construct();
			date_default_timezone_set('Asia/Jakarta');
			error_reporting(E_ALL);
			ini_set('Display Error', 1);
		}


		function getMovieById(){
			$idGenre = $this->input->post('idgenre');
			

   		 	$this->db->select("*");
			$this->db->from("tb_movie");
			$this->db->where("tb_movie.id_genre", $idGenre);
			$this->db->join("tb_genre", "tb_movie.id_genre = tb_genre.id_genre");
		
			$query = $this->db->get();
			if($query -> num_rows() > 0){
					$data['message'] = "Successfully Get Data Movie";
					$data['status'] = 200;
					$data['movie'] = $query->result();
			}else{
					$data['message'] = "Failed Get Data Movie";
					$data['status'] = 400;
			}
			
			echo json_encode($data);
		}

	}
?>